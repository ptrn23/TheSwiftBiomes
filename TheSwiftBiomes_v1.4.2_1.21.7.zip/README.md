<img src="theswiftbiomes.png">

## Introducing: The Swift Biomes!

**Are you a fan of Taylor Swift who happens to like Minecraft too? You're gonna be in love with The Swift Biomes!**

This datapack replaces the overworld with **ELEVEN (11) atmospheric biomes**, each reimagining the beauty of Taylor Swift's 11 studio albums. This datapack is originally dedicated to our public SMP named Swifties SMP where everyone can play and see the biomes in action. We have decided to release the raw datapack for the public too for fun!

Join now!: https://discord.gg/Qqkm6tB8UU

> [!NOTE] 
> <li> Other overworld biomes do NOT generate with the exception of ocean and river biomes. </li>
> <li> This world generation is not fit for survival but it would be a good challenge to try! </li>

